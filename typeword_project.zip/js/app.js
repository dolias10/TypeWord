let currentQuote = '';
let nextQuote = '';
let startTime;
let typedChars = 0;
let correctChars = 0;

const authorEl = document.getElementById('author');
const authorProfileEl = document.getElementById('authorProfile');
const currentQuoteEl = document.getElementById('current-quote');
const nextQuoteEl = document.getElementById('next-quote');
const typingInput = document.getElementById('typing-input');
const wpmEl = document.getElementById('wpm');
const accuracyEl = document.getElementById('accuracy');
const timeEl = document.getElementById('time');

async function fetchQuote() {
  const res = await fetch('https://korean-advice-open-api.vercel.app/api/advice');
  const data = await res.json();
  return data;
}

async function setQuotes() {
  let data1 = await fetchQuote();
  let data2 = await fetchQuote();
  currentQuote = data1.message;
  nextQuote = data2.message;
  authorEl.textContent = `말한 사람: ${data1.author}`;
  authorProfileEl.textContent = `(${data1.authorProfile})`;
  currentQuoteEl.textContent = currentQuote;
  nextQuoteEl.textContent = `다음: ${nextQuote}`;
  typingInput.value = '';
  startTime = new Date();
  typedChars = 0;
  correctChars = 0;
}

typingInput.addEventListener('input', () => {
  const val = typingInput.value;
  typedChars++;
  if (currentQuote.startsWith(val)) {
    correctChars++;
  }
  if (val === currentQuote) {
    // 다음 문장으로 이동
    currentQuote = nextQuote;
    fetchQuote().then(data => {
      nextQuote = data.message;
      nextQuoteEl.textContent = `다음: ${nextQuote}`;
    });
    currentQuoteEl.textContent = currentQuote;
    typingInput.value = '';
  }
  updateStats();
});

function updateStats() {
  const now = new Date();
  const seconds = Math.floor((now - startTime) / 1000);
  const wpm = Math.round((typedChars / 5) / (seconds / 60));
  const accuracy = Math.round((correctChars / typedChars) * 100);
  wpmEl.textContent = isNaN(wpm) ? 0 : wpm;
  accuracyEl.textContent = isNaN(accuracy) ? 0 : accuracy;
  timeEl.textContent = seconds;
}

setQuotes();