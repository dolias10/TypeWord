# TypeWord
한글 속담 타자연습 게임 (GitHub Pages 배포용)

## 실행
GitHub Pages에 업로드하면 `https://typeword.kro.kr` 에서 실행됩니다.

## 기능
- 속담/명언 API 연동
- 타자 속도(WPM), 정확도, 시간 표시
- 현재 문장, 다음 문장 표시
- 한글 UI
